#include <sstream>
#include <iostream>
#include <iomanip>

using namespace std;

class Example 
{
    protected :
        int a ;
    public:
        Example (int x ) {a =x;}
        virtual void format() 
		{
            cout.width(5);
            cout.fill('&');
            cout << a << endl;
        }

};
class ChildExample:public Example
{
    int a ;
    public:
        ChildExample (int x , int y ): Example(x) {a=y;}
        virtual void format() 
		{
            cout.width(4);
            cout.fill('?');
            cout << a << endl;
            cout.setf(ios::left,ios::adjustfield);
            cout.width(6);
            cout.fill('%');
            cout<< Example::a << endl;
	}
};

int main()
{
    Example *t[2];
    t[0] = new Example(10);
    t[0]->format();
    t[1] = new ChildExample (15,18);
    t[1]->format();
    delete [] t ;
    return 0;
}
