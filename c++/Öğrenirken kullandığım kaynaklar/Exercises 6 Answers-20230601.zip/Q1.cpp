#include<iostream>

using namespace std;

template<class T>
class Stack
{
	private:
		int size;
		int top;
		T* data;
	
	public:
		Stack(int s = 100):size(s), top(-1){ data = new T[size]; }
		~Stack() { delete []data;}
		
		void push(const T& x) 
		{
			data [++top] = x;
		}
		
		T pop() 
		{
			return data[top--];
		}
		
		int isEmpty() const{return top == -1;}
		int isFull() const{return top == size-1;}
		
};

int main()
{
	Stack<int> intStack1(5);
	Stack<int> intStack2(10);
	Stack<char> charStack1(8);
	Stack<char> charStack2(9);
	
	intStack1.push(33);
	charStack1.push('M');
	intStack2.push(11);
	charStack2.push('B');
	charStack2.push('S');
	intStack2.push(77);
	cout<<" "<<"intStack1: "<<intStack1.pop()<<endl;
	cout<<" "<<"charStack1: "<<charStack1.pop()<<endl;
	cout<<" "<<"intStack2: "<<intStack2.pop()<<endl;
	cout<<" "<<"intStack2: "<<intStack2.pop()<<endl;
	if(intStack2.isEmpty())
	{
		cout<<" "<<"intStack2 is Empty!\n";
	}
}
