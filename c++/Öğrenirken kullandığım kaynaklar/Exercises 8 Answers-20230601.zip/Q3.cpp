/*  C++ Program to Merge Two Files into a Single file  */

#include<iostream>
#include<fstream>
#include<stdio.h>
#include<stdlib.h>
using namespace std;

int main()
{
        ifstream file1, file2;
        ofstream merge;

        char ch, fname1[100], fname2[100], fname3[100];

        cout<<"Enter first file name :: ";
        cin>>fname1;
        cout<<"\nEnter second file name :: ";
        cin>>fname2;
        cout<<"\nEnter third name of file :: ";
        cin>>fname3;

        file1.open(fname1);
        file2.open(fname2);

        if(!file1 || !file2)
        {
                perror("\nError Message in file1111 ");
                cout<<"\nPress any key to exit...\n";

                exit(EXIT_FAILURE);
        }

        merge.open(fname3);

        if(!merge)
        {
                perror("\nError Message ");
                cout<<"\nPress any key to exit...\n";

                exit(EXIT_FAILURE);
        }

        while(file1.eof()==0)
        {
                file1>>ch;
                merge<<ch;
        }

        while(file2.eof()==0)
        {
                file2>>ch;
                merge<<ch;
        }

        cout<<"\nThe two files were merged into "<<fname3<<" file successfully....!!\n";

        file1.close();
        file2.close();
        merge.close();

        return 0;
}
