#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ifstream myFile ("input.txt");

//  ifstream myfile ("input.txt",ios::in)
    int wordCounter=0, lineCounter=0, charCounter=0, lowerCounter=0, upperCounter=0, blankCounter=0 ;
    char ch;

    while(!myFile.eof()) // go to the end of file
    {

        myFile.get(ch); // read file char by char

        if (ch == '\n')
            lineCounter ++; // count line

        else if (ch == ' ' || ch =='.')
            {
               wordCounter++; // count word
                if (ch == ' ')
                {
                     blankCounter ++; // count blank character
                }
            }

        else
        {

                // charCounter ++;
            if ( ch > 64 && ch < 91 ) // count upper case word
                upperCounter ++;
            else if( ch > 96 && ch < 123 ) // count lower case word
                lowerCounter ++ ;

        }

        charCounter ++;
    }
    cout << "Total number of word is :" << wordCounter << endl;
    cout << "Total number of line is :" << lineCounter << endl;
    cout << "Total number of character is: " << charCounter << endl;
    cout << "Total number of upper case  is : " << upperCounter << endl;
    cout << "Total number of lower case  is : " << lowerCounter << endl;
    cout << "Total number of blank character is : " << blankCounter << endl;

    myFile.close();
    return 0;
}
