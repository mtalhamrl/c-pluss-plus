#include<iostream>

using namespace std;

class Shape
{
	protected:
		int locX,locY;
	public:
		Shape(int x=0, int y=0){locX=x;locY=y;}
		virtual void print()
		{
			cout<<"Shape Coordinates ("<<locX<<"-"<<locY<<")"<<endl;
		}
};

class Circle:public Shape
{
	private:
		int radius;
	public:
		Circle(int x=0, int y=0, int r=0):Shape(x,y){radius=r;}
		void print()
		{
			cout<<"Circle Coordinates ("<<locX<<"-"<<locY<<") and it's radius is "<<radius<<endl;
		}
};

class Rectangle:public Shape
{
	private:
		int height,width;
	public:
		Rectangle(int x=0, int y=0, int h=0, int w=0):Shape(x,y){height=h;width=w;}	
		void print()
		{
			cout<<"Rectangle Coordinates :("<<locX<<"-"<<locY<<") ("<<width<<"-"<<height<<")"<<endl;
		}
};

void reportShapes(Shape *p)
{
	p->print();
}

int main()
{
	Shape vShape(3,4);
	Circle vCirc(2,3,4);
	Rectangle vRect(4,5,1,2);
	
	reportShapes(&vShape);
	reportShapes(&vCirc);
	reportShapes(&vRect);
	
	return 0;
}























