#include<iostream>
#include <string>

using namespace std;

class OEM
{
	private:
		string name,brand;
		double price,dolarExchangeRate,taxRate;
	public:	
	OEM(string n="",string b="",double p=0):name(n),brand(b),price(p)
	{
		dolarExchangeRate=19.51;
		taxRate=1.18;
		SetPrice(price,dolarExchangeRate,taxRate);
	}
	
	void SetPrice(double p,double dE,double tR)
	{
		this->price=p*dE+p*dE*tR;
		
	}
	
	double getPrice()
	{
		return price;
	}
	
	string getName()
	{
		return name;
	}
	
	string getBrand()
	{
		return brand;
	} 

};
class CPU:public OEM
{
	private:
	string serialNumber;
	double clockSpeed,cache;
	int memoryWidth;
	public:
	CPU(string n="",string b="",double p=0,string sn="",double cs=0,double ch=0,int mw=0):OEM(n,b,p),serialNumber(sn),clockSpeed(cs),cache(ch),memoryWidth(mw)
	{	
	}
	
	void PrintInformation()
	{
		cout<<"Brand:"<<getBrand()<<"\nName: "<<getName()<<"\nSerial Number: "<<serialNumber<<"\nClock Speed:"<<clockSpeed<<" Ghz\nCache: "<<cache<<" Mb\nMemory Width:"<<memoryWidth<<" Mb\n"<<"Price as TL:"<<getPrice()<<endl;
		
	}
			
};

int main()
{
	CPU i7("I7","Intel",400,"7700k",4.2,8,62);
	i7.PrintInformation();
	
	return(0);
}
