#include <iostream>
#include <exception>

using namespace std;
 
class OverSpeed : public exception
{
	int speed;
	public :
    const char* control()
	{
    	return "Please check out your car speed!! You are about to exceed 100 !!!";
    }
};
   
int main()
{
 	int carspeed=0;
 	try
   	{
    	while(1)
   	{
    	carspeed+=10;
    	if(carspeed>100)
    	{
 
    	OverSpeed s;
    	throw s;
    	}
    	cout<<"Carspeed: "<<carspeed<<endl;
 }
 
 }
 catch(OverSpeed ex)
 {
 	cout<<ex.control();
 }
 
 	return 0;
}
