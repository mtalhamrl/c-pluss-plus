#include<iostream>
#include<stdexcept> //contains runtime_error

using namespace std;

//DivideByZeroException objects should be thrown by functions
//upon detecting division-by-zero exceptions
class DivideByZeroException : public std::runtime_error
{
	public:
	//constructor specifies default error message
	DivideByZeroException()
	: std::runtime_error{"attempted to divide by zero"}{}
};

double quotient(int num,int den)
{
	if(den==0)
	{
		throw DivideByZeroException{};
	}
	//return division result
	return static_cast<double>(num)/den;
}
int main()
{
	int num1,num2;
	
	cout<<"Enter two integers: ";
	while(cin>>num1>>num2)
	{
		//try block contains code that migth throw exception
		//and code that will not execute if an exception occurs
		try
		{
			double result{quotient(num1,num2)};
			cout<<"The quotient is: "<<result<<endl;
		}
		catch(const DivideByZeroException& divideByZeroException)
		{
			cout<<"Exception occured: "<<divideByZeroException.what()<<endl;
		}
		cout<<"Enter two integers: ";
	}
	cout<<endl;
}
