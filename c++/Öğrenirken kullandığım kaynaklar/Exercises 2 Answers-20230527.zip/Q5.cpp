#include <iostream>

using namespace std;

class Employee
{
	private:
		string name;
		string position;
		double salary;
	public:
	    Employee()
	    {
	        cout<<"Enter employee's name:";
            cin>>name;
            cout<<"Enter the position:";
            cin>>position;
            cout<<"Enter the salary:";
            cin>>salary;
	    }

		void display()
		{
			cout<<"Employee's name:"<<name<<endl;
			cout<<"Position:"<<position<<endl;
			cout<<"Salary:"<<salary<<endl;
		}

		void raise(int per, string pos)
		{
			if(position==pos)
				salary+=salary*per/100;
		}

};

int main()
{
	int inc;
	string rpos;
	cout<<"Add employees:"<<endl;
	Employee employees[3];
	
	cout<<"Enter the raise percentage:";
	cin>>inc;
	cout<<"Enter the position of the employees to raised: ";
	cin>>rpos;
	for(int i=0;i<3;i++)
	{
		cout<<"Before raise:"<<endl;
		employees[i].display();
		employees[i].raise(inc,rpos);
		cout<<"After raise:"<<endl;
		employees[i].display();
	}

	return 0;
}
