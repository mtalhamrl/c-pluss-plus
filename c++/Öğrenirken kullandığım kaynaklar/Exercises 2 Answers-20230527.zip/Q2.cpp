#include<iostream>
#include<stdlib.h>

using namespace std;

class Character
{
	private:
		float health=100;
		float minDamage;
		float maxDamage;
	public:
		Character(float _minDamage, float _maxDamage)
		{
			minDamage = _minDamage;
			maxDamage = _maxDamage;
		}
		
		float GetHealth()
		{
			return health;
		}
		
		float Damage();
		void TakeDamage(float);
		
};

float Character::Damage()
{
	return (maxDamage - minDamage) * ((((float) rand()) / (float)RAND_MAX)) + minDamage;
}

void Character::TakeDamage(float dmg)
{
	health -= dmg;
	if(health<0)
		health=0;
}


int main(void)
{	
	char input;
	Character player(5.0,10.0);
	Character enemy(5.0,10.0);
	while(player.GetHealth()>0 && enemy.GetHealth()>0)
	{
		cout<<"Player Health: "<<player.GetHealth()<<endl;
		cout<<"Enemy Health: "<<enemy.GetHealth()<<endl;
		cin>>input;
		if(input=='e')
		{
			float pdamage = player.Damage();
			enemy.TakeDamage(pdamage);
			float edamage = enemy.Damage();
			player.TakeDamage(edamage);
		}
	}
	cout<<"Player Health: "<<player.GetHealth()<<endl;
	
	cout<<"Enemy Health: "<<enemy.GetHealth()<<endl;
}
