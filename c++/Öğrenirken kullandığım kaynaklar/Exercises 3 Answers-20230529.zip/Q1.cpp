#include <iostream>

using namespace std;

class Calculation 
{
    private:
    	int x;
    public:
    	void set_value(int num)
    	{
        	x=num;
        
    	}
    
    void show_sum(int n)
    {
        cout<<"Sum of "<<x<<" and "<<n<<" = "<<x+n<<endl;
        
    }

};

class Comp 
{
    public:
    	Calculation object2;
    void print_result()
    {
     	object2.show_sum(7);
    }
    
};
 
int main()
{
  Comp object1;
  object1.object2.set_value(33); //one dot operator is used to access the member of the object1
  								//that is object2, and second is used to acces the member function set_value()
  								//of sub-object object2 and x is assigned to 33.
  object1.object2.show_sum(100);
  object1.print_result();
}
