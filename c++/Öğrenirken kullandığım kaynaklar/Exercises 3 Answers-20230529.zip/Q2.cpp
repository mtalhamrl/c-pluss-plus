#include<iostream>
using namespace std;

class Address
{	
	private: 
		string addressLine, city, state;
	public:
		Address (string addL, string c, string st)
		{
			addressLine = addL;
			city = c;
			state = st;
		}
		string getAddLine()
		{
			return addressLine;
		}
		string getCity()
		{
			return city;
		}
		string getState()
		{
			return state;
		}
	
};
class Employee
{
	private:
	Address* address1;	
	public:
		
		int id;
		string name;
		Employee (int id1,string name1, Address* address_1){
			id = id1;
			name = name1;
			address1 = address_1;
		}
		void display()
		{
			cout<<id <<" "<< name<< address1->getAddLine() <<" "<<address1->getCity()<<" "<< address1->getState()<<endl;
		}
	
};

int main(void) 
{  
    Address adress("Bahcelievler 7.Cadde","Ankara","TR");    
    Employee employee = Employee(225,"Stephen Curry ",&adress);    
    employee.display();   
    
	return 0;  
}      
