#include<iostream>

using namespace std;

class Employee
{
	public:
		Employee(const string&, const string&);	
		~Employee();
		string getFirstName() const; //return first name
		string getLastName() const; //return last name
		
		//static member function
		static int getCount(); //return # of objects instantiated
		string firstName;
		string lastName;
		
		//static data
		static int count; //number of objects instantiated
};

//define and initialize static data member at global namespace scope 
int Employee::count{0}; //cannot include keyword static

int Employee::getCount(){return count;}

//constructor initializes non-static data members and increments static data member count
Employee::Employee(const string& first, const string& last):firstName(first), lastName(last)
{
	++count; //increment static count of employees
	cout<<"Employee constructor for "<<firstName<<' '<<lastName<<" called."<<endl;
}

//destructor decrements the count
Employee::~Employee()
{
	cout<<"~Employee() called for "<<firstName<<' '<<lastName<<endl;
	--count; //decrement static count of employees
}

//return first name of employee
string Employee::getFirstName() const{return firstName;}
//return last name of employee
string Employee::getLastName() const{return lastName;}

int main()
{
	//no objs exist; use class name and binary scope resolution operator to access static member func getCount
	cout<<"Number of employees before instantiation of any objects is "<<Employee::getCount()<<endl;
	
	//the following scope creates and destroys Employee objects before main terminates
	Employee e1({"Kobe", "Bryant"});
	Employee e2({"Stephen", "Curry"});
	
	cout<<"Number of employees after objects are instantiated is "<<Employee::getCount()<<endl;
	cout<<"\n\nEmployee 1: "<<e1.getFirstName()<<" "<<e1.getLastName()<<"\nEmployee 2: "<<e2.getFirstName()<<" "<<e2.getLastName()<<"\n\n";
	cout<<"Number of employees after objects are deleted is "<<Employee::getCount()<<endl;
}


