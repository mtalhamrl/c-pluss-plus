#include<iostream>
using namespace std;

class Person
{
	private:
		string name;
	public:
	
		void display(string name)
		{
			cout<<name<<endl;
		}
};

int main()
{
	Person p1;
	p1.display("gizem");
}
