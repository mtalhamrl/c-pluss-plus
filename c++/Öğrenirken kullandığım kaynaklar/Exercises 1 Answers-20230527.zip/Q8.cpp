#include <iostream>
using namespace std;

class Sports
{	
	public:
		Sports(string name)
		{
			cout<<name<<" is created."<<endl;
		}
			
};

main()
{
     Sports obj("Basketball");

     return(0);
}

