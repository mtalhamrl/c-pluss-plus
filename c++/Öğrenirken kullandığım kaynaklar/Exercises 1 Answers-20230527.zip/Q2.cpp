#include <iostream>

using namespace std;

int add(int a, int b)
{
	cout << "I am the first one"<<endl;
	return a+b;
}

double add(int a, double b)
{
	cout << "I am the second one"<<endl;
	return a+b;
}

double add(double a, int b)
{
	cout << "I am the third one"<<endl;
	return a+b;
}

double add(double a, double b)
{
	cout << "I am the fourth one"<<endl;
	return a+b;
}

int main(){
	cout << add(2,3)<<endl;
	cout << add(2,3.1)<<endl;
	cout << add(2.1,3)<<endl;
	cout << add(2.1,3.1)<<endl;
	//double x=add(2.1,3.1);
	//cout<<x<<endl;
}

