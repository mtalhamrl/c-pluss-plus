#include <iostream>

using namespace std;

template <typename T1, typename T2,typename T3>
T1 add(T2 a, T3 b)
{
	return a+b;
}

int main()
{
	cout << "I am the first one"<<endl;
	cout << add<int,int,int>(2,3)<<endl;
	cout << "I am the second one"<<endl;
	cout << add<double,int,double>(2,3.1)<<endl;
	cout << "I am the third one"<<endl;
	cout << add<double,double,int>(2.1,3)<<endl;
	cout << "I am the fourth one"<<endl;
	cout << add<double,double,double>(2.1,3.1)<<endl;
	cout << "I am the fourth one"<<endl;
	double x=add<double,double,double>(2.1,3.1);
	cout<<x<<endl;
}

